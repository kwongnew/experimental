#!/system/bin/sh
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false

print_modname() {
  ui_print "====================================="
  ui_print "  状态栏时间显示秒 · Magisk 模块"
  ui_print "====================================="
}

on_install() {
  ui_print "- 安装配置..."
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}

run_install